﻿using System;

namespace DelegatesDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
