﻿// Note - the project is using implicit and global usings 

namespace $safeprojectname$
{
    class Configuration
    {
        public string Name { get; set; }
        public int Version { get; set; }        
        public string[] Args { get; set; }
    }
}
