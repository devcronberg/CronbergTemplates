﻿namespace $safeprojectname$
{
    internal interface IServiceTest
    {
        void Test();
    }
}