﻿// Note - project is using implict and global usings 
namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
