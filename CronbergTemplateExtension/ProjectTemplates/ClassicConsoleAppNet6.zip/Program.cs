﻿// Note - the project is using implicit and global usings 
namespace $safeprojectname$
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
