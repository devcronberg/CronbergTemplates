﻿// Note - project is using implict and global usings 
namespace $safeprojectname$
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            
        }
    }
}
