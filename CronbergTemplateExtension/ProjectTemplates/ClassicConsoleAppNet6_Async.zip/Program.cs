﻿// Note - the project is using implicit and global usings 
namespace $safeprojectname$
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            await Task.Run(() => { });
        }
    }
}
